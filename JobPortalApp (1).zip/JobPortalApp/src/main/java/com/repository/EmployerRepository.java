package com.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entities.Employer;

//Provide necessary annotation
@Repository
public interface EmployerRepository extends JpaRepository<Employer, String> {
	
	Employer findByemployerId(String employerId);
	List<Employer> findByIndustry(String industry);
	List<Employer> findByJobPostingsList_Title(String title);
	//Provide necessary method to view employer based on industry,
	//to view Employers by JobPost title and to get the Employer wise total JobPost count 
}