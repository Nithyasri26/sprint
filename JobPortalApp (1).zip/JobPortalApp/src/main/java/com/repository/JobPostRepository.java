package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entities.JobPost;

//Provide necessary annotation
public interface JobPostRepository extends JpaRepository<JobPost, String>{
	List<JobPost> findAll();
	List<JobPost> findBySalaryOfferedGreaterThanEqual(Double salaryOffered);
	List<JobPost> findByEmployerObj_CompanyNameAndEmployerObj_Location(String companyName,String location);
//	 Provide necessary method methods to view JobPosts by salaryOffered, and view 
//	JobPosts by companyName and location	
}