package com.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import com.entities.Employer;
import com.entities.JobPost;
import com.exception.InvalidEmployerException;
import com.repository.EmployerRepository;
import com.repository.JobPostRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployerServiceImpl implements IEmployerService {
		// Provide necessary Annotation
	    @Autowired
		private EmployerRepository empRepository;
	    
	    @Autowired
	    private JobPostRepository jobRepository;

		public Employer addEmployer(Employer employerObj) {
			return empRepository.save(employerObj);
		}
		
		public Employer updateLocation(String employerId, String location) throws InvalidEmployerException
		{
			Supplier<InvalidEmployerException> s=() -> new InvalidEmployerException("No employer found");
			Employer employer = empRepository.findById(employerId).
					orElseThrow(s);
			employer.setLocation(location);
			empRepository.save(employer);
			return employer;
		}
		
		public Employer viewEmployerById(String employerId) throws InvalidEmployerException
		{
			Optional<Employer> employerObj =empRepository.findById(employerId);
			if(employerObj.isPresent())
				return empRepository.findByemployerId(employerId);
			else
				throw new InvalidEmployerException("No employer found");
			
		}
		
		public List<Employer> viewEmployersByIndustry(String industry)
		{
			return empRepository.findByIndustry(industry);
		}
		
		public List<Employer> viewEmployersByJobTitle(String title){
			return empRepository.findByJobPostingsList_Title(title);
		}
		
		public Map<String,Integer> getEmployerWiseJobCount(){
			List<JobPost> jobs = jobRepository.findAll();
			return jobs.stream().collect(Collectors.groupingBy(
					job -> job.getEmployerObj().getEmployerId(),
					Collectors.summingInt(job -> 1)));
		}
		
}
