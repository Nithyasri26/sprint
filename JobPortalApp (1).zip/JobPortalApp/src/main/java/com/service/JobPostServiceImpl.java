package com.service;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import com.entities.Employer;
import com.entities.JobPost;
import com.exception.InvalidEmployerException;
import com.exception.InvalidJobPostException;
import com.repository.EmployerRepository;
import com.repository.JobPostRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class JobPostServiceImpl implements IJobPostService {

	// Provide necessary Annotation
	@Autowired
	private JobPostRepository jobRepository;

	// Provide necessary Annotation
	@Autowired
	private EmployerRepository empRepository;

	public JobPost addJobPost(JobPost jobPostObj, String employerId) throws InvalidEmployerException
	{
		Optional<Employer> employerObj = empRepository.findById(employerId);
		if(employerObj.isPresent())
		{
			jobPostObj.setEmployerObj(employerObj.get());
			return jobRepository.save(jobPostObj);
		}
		else
			throw new InvalidEmployerException("Employer not found");
	}
	
	public JobPost updateOfferedSalary(String jobId, double salaryOffered) throws InvalidJobPostException
	{
		Supplier<InvalidJobPostException> s=() -> new InvalidJobPostException("Job not found");
		JobPost jobObj = jobRepository.findById(jobId).
				orElseThrow(s);
		jobObj.setSalaryOffered(salaryOffered);
		return jobRepository.save(jobObj);
	}	
	
	public List<JobPost> viewJobsBySalaryOffered(double salaryOffered)
	{
		return jobRepository.findBySalaryOfferedGreaterThanEqual(salaryOffered);
	}
	
	public List<JobPost> viewJobsByCompanyAndLocation(String companyName, String location){
		return jobRepository.findByEmployerObj_CompanyNameAndEmployerObj_Location(companyName,location);
	}
	
	public JobPost markJobPostAsClosed(String jobId) throws InvalidJobPostException {
		Supplier<InvalidJobPostException> s=() -> new InvalidJobPostException("Job not found");
		JobPost jobObj = jobRepository.findById(jobId).
				orElseThrow(s);
		jobRepository.deleteById(jobId);
		return jobObj;
	}
}
