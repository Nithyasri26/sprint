package com.entities;

import java.util.List;

import org.hibernate.annotations.DynamicUpdate;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;

//Provide necessary Annotation
@Entity
@Data
@AllArgsConstructor
@DynamicUpdate
public class Employer {
		
	// Provide necessary Annotation
	@Id
	private String employerId;
	
	private String companyName;
	private String industry;
	private String location;
	@OneToMany(mappedBy = "employerObj",fetch=FetchType.LAZY)
	private List<JobPost> jobPostingsList;
	
	public Employer() {
		
	}
}
