package com.exception;

public class InvalidJobPostException extends Exception {
	public InvalidJobPostException(String msg) {
		super(msg);
	}
}
