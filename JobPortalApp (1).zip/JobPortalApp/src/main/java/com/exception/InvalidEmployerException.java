package com.exception;

public class InvalidEmployerException  extends Exception {
	public InvalidEmployerException(String message) {
		super(message);
	}
}
